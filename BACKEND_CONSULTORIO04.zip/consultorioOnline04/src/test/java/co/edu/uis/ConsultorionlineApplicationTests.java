package co.edu.uis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultorionlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
