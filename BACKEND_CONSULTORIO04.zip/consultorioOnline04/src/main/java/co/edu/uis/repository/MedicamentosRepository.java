package co.edu.uis.repository;

import org.springframework.data.repository.CrudRepository;

import co.edu.uis.models.Medicamentos;

public interface MedicamentosRepository extends CrudRepository<Medicamentos, Integer>{

}
