package co.edu.uis.service.implement;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import co.edu.uis.models.Medicamentos;
import co.edu.uis.repository.MedicamentosRepository;
import co.edu.uis.service.MedicamentosService;

@Service
public class MedicamentosServiceImpl implements MedicamentosService {
	
	@Autowired
	private MedicamentosRepository medicamentosRepository;
	
	@Override
	@Transactional(readOnly=false)
	public Medicamentos save(Medicamentos medicamentos) {
		return medicamentosRepository.save(medicamentos);
	}
	
	@Override
	@Transactional(readOnly=false)
	public void delete(Integer id) {
		medicamentosRepository.deleteById(id);
	}
	
	@Override
	@Transactional(readOnly=true)
	public Medicamentos findById(Integer id) {
		return medicamentosRepository.findById(id).orElse(null);
	}
	
	@Override
	@Transactional(readOnly=true)
	public List<Medicamentos> findAll() {
		return (List<Medicamentos>) medicamentosRepository.findAll();
	}
}

