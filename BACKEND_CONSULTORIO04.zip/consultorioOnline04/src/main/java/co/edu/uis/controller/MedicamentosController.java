package co.edu.uis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.edu.uis.models.Medicamentos;
import co.edu.uis.service.MedicamentosService;

@RestController
@CrossOrigin("*")
@RequestMapping("/medicamentos")
public class MedicamentosController {
	
@Autowired
private MedicamentosService medicamentosservice;

@PostMapping(value="/")
public ResponseEntity<Medicamentos> agregar(@RequestBody Medicamentos medicamentos){
	Medicamentos obj= medicamentosservice.save(medicamentos);
	return new ResponseEntity<>(obj, HttpStatus.OK);
}

@DeleteMapping(value="/{id}")
public ResponseEntity<Medicamentos> eliminar(@PathVariable Integer id){
	Medicamentos obj=medicamentosservice.findById(id);
	if(obj!=null)
		medicamentosservice.delete(id);
	else
		return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR);
	return new ResponseEntity<>(obj,HttpStatus.OK);
	}

@PutMapping(value="/")
public ResponseEntity<Medicamentos> editar(@RequestBody Medicamentos medicamentos){
Medicamentos obj= medicamentosservice.findById(medicamentos.getId_medicam());
if(obj!=null)
{
	obj.setId_medicam(medicamentos.getId_medicam());
	obj.setNombre_medicam(medicamentos.getNombre_medicam());
	obj.setVenc_medicam(medicamentos.getVenc_medicam());
	obj.setPresent_medicam(medicamentos.getPresent_medicam());
	medicamentosservice.save(obj);
}
else
	return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR);
return new ResponseEntity<>(obj, HttpStatus.OK);
}

@GetMapping(value="/list")
public List<Medicamentos> consultarTodo(){
	return medicamentosservice.findAll();
}

@GetMapping(value="/List/{id}")
public Medicamentos consultarPorId(@PathVariable Integer id) {
	return medicamentosservice.findById(id);
}

}
