package co.edu.uis.models;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="medicamentos")
public class Medicamentos implements Serializable {
	
	@Id
	@Column(name="id_medicam")
	private Integer id_medicam;
	
	@Column(name="nombre_medicam")
	private String nombre_medicam;
	@Column(name="venc_medicam")
	private Date venc_medicam;
	@Column(name="present_medicam")
	private String present_medicam;
	public Medicamentos(Integer id_medicam, String nombre_medicam, Date venc_medicam, String present_medicam) {
		super();
		this.id_medicam = id_medicam;
		this.nombre_medicam = nombre_medicam;
		this.venc_medicam = venc_medicam;
		this.present_medicam = present_medicam;
	}
	public Medicamentos() {
		super();
	}
	public Integer getId_medicam() {
		return id_medicam;
	}
	public void setId_medicam(Integer id_medicam) {
		this.id_medicam = id_medicam;
	}
	public String getNombre_medicam() {
		return nombre_medicam;
	}
	public void setNombre_medicam(String nombre_medicam) {
		this.nombre_medicam = nombre_medicam;
	}
	public Date getVenc_medicam() {
		return venc_medicam;
	}
	public void setVenc_medicam(Date venc_medicam) {
		this.venc_medicam = venc_medicam;
	}
	public String getPresent_medicam() {
		return present_medicam;
	}
	public void setPresent_medicam(String present_medicam) {
		this.present_medicam = present_medicam;
	}
	@Override
	public String toString() {
		return "Medicamentos [id_medicam=" + id_medicam + ", nombre_medicam=" + nombre_medicam + ", venc_medicam="
				+ venc_medicam + ", present_medicam=" + present_medicam + "]";
	}

	
	
}