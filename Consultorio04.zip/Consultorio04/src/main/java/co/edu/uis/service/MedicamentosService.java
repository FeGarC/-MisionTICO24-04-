package co.edu.uis.service;

import java.util.List;

import co.edu.uis.model.Medicamentos;

public interface MedicamentosService {
	
	public Medicamentos save(Medicamentos medicamentos);
	public void delete(Integer id);
	public Medicamentos findById(Integer id);
	public List<Medicamentos> findAll();

}
