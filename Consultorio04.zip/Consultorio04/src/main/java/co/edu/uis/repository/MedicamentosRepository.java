package co.edu.uis.repository;

import org.springframework.data.repository.CrudRepository;

import co.edu.uis.model.Medicamentos;

public interface MedicamentosRepository extends CrudRepository<Medicamentos, Integer>{

}
