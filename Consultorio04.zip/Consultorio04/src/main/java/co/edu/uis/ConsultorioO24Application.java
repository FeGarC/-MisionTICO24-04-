package co.edu.uis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsultorioO24Application {

	public static void main(String[] args) {
		SpringApplication.run(ConsultorioO24Application.class, args);
	}

}
