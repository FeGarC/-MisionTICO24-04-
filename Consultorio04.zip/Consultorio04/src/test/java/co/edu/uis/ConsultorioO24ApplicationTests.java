package co.edu.uis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultorioO24ApplicationTests {

	@Test
	void contextLoads() {
	}

}
