function loadData(){
    let request = sendRequest('medicamentos/list', 'GET', '')
    let table = document.getElementById('medicamentos-table');
    table.innerHTML = "";
    request.onload = function(){
        
        let data = request.response;
        console.log(data);
        data.forEach((element, index) => {
            table.innerHTML += `
                <tr>
                    <th>${element.id_medicam}</th>
                    <td>${element.nombre_medicam}</td>
                    <td>${element.venc_medicam}</td>
                    <td>${element.present_medicam}</td>
                    <td>
                        <button type="button" class="btn btn-primary" onclick='window.location = "medicam_formedit.html?id=${element.id_medicam}"'>Editar</button>
                        <button type="button" class="btn btn-danger" onclick='deleteMedicamento(${element.id_medicam})'>Eliminar</button>
                    </td>
                </tr>

                `
        });
    }
    request.onerror = function(){
        table.innerHTML = `
            <tr>
                <td colspan="6">Error al recuperar los datos.</td>
            </tr>
        `;
    }
}

function loadMedicamento(id_medicam){
    let request = sendRequest('medicamentos/List/'+id_medicam, 'GET', '')
    let id = document.getElementById('medicam-id')
    let nombre = document.getElementById('medicam-nom')
    let fecha = document.getElementById('medicam-venc')
    let present = document.getElementById('medicam-present')
    request.onload = function(){
        
        let data = request.response
        id.value = data.id_medicam
        nombre.value = data.nombre_medicam
        fecha.value = data.venc_medicam
        present.value = data.present_medicam
        
    }
    request.onerror = function(){
        alert("Error al recuperar los datos.");
    }
}

function deleteMedicamento(id_medicam){
    let request = sendRequest('medicamentos/'+id_medicam, 'DELETE', '')
    request.onload = function(){
        loadData()
    }
}

function saveMedicamento(){
    let id = document.getElementById('medicam-id').value
    let nombre = document.getElementById('medicam-nom').value
    let fecha = document.getElementById('medicam-venc').value
    let present = document.getElementById('medicam-present').value
    var data = {'id_medicam': id,'nombre_medicam':nombre,'venc_medicam': fecha, 'present_medicam': present}
    let request = sendRequest('medicamentos/', 'POST', data)
    request.onload = function(){
        window.location = 'medicamentos.html';
    }
    request.onerror = function(){
        alert('Error al guardar los cambios.')
    }
}
